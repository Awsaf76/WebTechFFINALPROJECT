<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyMate | Sign Up</title>

    <style>
        /* ... (your existing CSS styles) ... */
    </style>
</head>

<body>
    <fieldset>
        <fieldset>
            <header>
                <h1>StudyMate</h1>
                <nav>
                    <a href="login.php">Login</a>
                    <a href="signup.php">| Signup</a>
                </nav>
            </header>
            <div class="container">
                <div class="links">
                    <form method="POST" action="../controller/regCheck.php" onsubmit="return validateForm()">
                        Username: <input type="text" name="username" id="username" value="" /><br><br>
                        Name: <input type="text" name="name" id="name" value="" /><br><br>
                        Email: <input type="email" name="email" id="email" value="" /> <br><br>
                        Gender: <input type="radio" name="gender" value="male" /> Male
                        <input type="radio" name="gender" value="female" /> Female
                        <input type="radio" name="gender" value="other" /> Other
                        <br><br>
                        Date of Birth: <input type="date" name="dateofbirth" id="dateofbirth" value="" /><br><br>
                        Password: <input type="password" name="password" id="password" value="" /> <br><br>
                        <input type="submit" name="submit" value="Submit" />
                    </form>
                </div>
            </div>
        </fieldset>
    </fieldset>

    <script>
        function validateForm() {
            // Get form input values
            var username = document.getElementById("username").value.trim();
            var name = document.getElementById("name").value.trim();
            var email = document.getElementById("email").value.trim();
            var gender = document.querySelector('input[name="gender"]:checked');
            var dateofbirth = document.getElementById("dateofbirth").value;
            var password = document.getElementById("password").value;

            // Check if all fields are filled
            if (!username || !name || !email || !gender || !dateofbirth || !password) {
                alert("Please fill all the required fields.");
                return false;
            }

            // Additional validations can be added for each input field, for example:
            // - Validate username to be at least 4 characters long
            // - Validate email format
            // - Validate password strength

            // If all validations pass, show a success message and allow form submission
            alert("Sign up successful!");
            return true;
        }
    </script>
</body>

</html>
