<!DOCTYPE html>
<html>
<head>
    <title>Upload Picture</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
        }
        input[type="file"] {
            display: block;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn-submit {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 4px;
        }
        .success {
            background-color: #D4EDDA;
            color: #155724;
        }
        .error {
            background-color: #F8D7DA;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Upload Picture</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="picture">Select Picture:</label>
                <input type="file" id="picture" name="picture">
            </div>
            <button type="submit" class="btn-submit">Upload</button>
        </form>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $picture = $_FILES['picture'];

            // Check if file was uploaded without errors
            if ($picture['error'] == UPLOAD_ERR_OK) {
                // Store picture in SQL database
                $pdo = new PDO('mysql:host=localhost;dbname=studymate', 'root', '');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $pdo->prepare('INSERT INTO pictures (name, data) VALUES (?, ?)');
                $stmt->execute([$picture['name'], file_get_contents($picture['tmp_name'])]);
                echo '<div class="message success">File uploaded and stored in the database successfully.</div>';
            } else {
                echo '<div class="message error">Error uploading file.</div>';
            }
        }
        ?>
    </div>
    <!-- Link to your other pages or navigation menu here -->

    <!-- Create the back button -->
    <button id="backButton">Back</button>

    <script>
        // Get the back button element
        const backButton = document.getElementById("backButton");

        // Add a click event listener to the back button
        backButton.addEventListener("click", () => {
            // Use the history object to go back one step in the browser history
            window.history.back();
        });
    </script>
</body>
</html>
