<?php
// Check if the form is submitted and the file is uploaded successfully
if (isset($_POST['submit']) && isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "studymate";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // File details
    $videoName = $_FILES['video']['name'];
    $videoType = $_FILES['video']['type'];
    $videoTmpPath = $_FILES['video']['tmp_name'];

    // Move the uploaded file to a desired location on the server
    $uploadPath = "uploads/";
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0777, true); // Create the "uploads" directory with full permissions (0777)
    }
    $uploadedFile = $uploadPath . $videoName;
    if (!move_uploaded_file($videoTmpPath, $uploadedFile)) {
        die("Failed to move the uploaded file.");
    }

    // Save the video details to the database using prepared statements for security
    $sql = "INSERT INTO videos (file_name, file_type) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $videoName, $videoType);

    if ($stmt->execute()) {
        echo "Video uploaded successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $stmt->error;
    }
    echo '<br><button onclick="window.location.href=\'home.php\'">Back to Home</button>';

    $stmt->close();
    $conn->close();

    
}
?>
