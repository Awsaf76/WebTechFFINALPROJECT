<!DOCTYPE html>
<html lang="en">
<head>
<form action="search.php" method="POST">
    <div class="search-container">
        <label for="search">Search for users:</label>
        <div class="search-box">
            <input type="text" id="search" name="search" required size="60">
            <input type="submit" value="Search">
        </div>
    </div>
</form>
<style>
    .search-box {
        display: inline-block;
        background-color: grey;
        padding: 1px;
        border-radius: 1px;
        float: right; /* Move the search box to the right */
    }

    /* Optional: Style the label to match the design */
    label {
        color: white;
        font-weight: bold;
    }
</style>

</form>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        /* Global styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        /* Header styles */
        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        /* Navigation styles */
        nav {
            background-color: #444;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        /* Picture box styles */
        .picture-box {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 150px;
            height: 150px;
            border: 2px solid #000;
            overflow: hidden;
        }

        .picture-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Content styles */
        .content {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>StudyMate</h1>
    </header>

    <nav>
        <a href="group.php">Create Groups</a>
        <a href="upload_picture.php">Upload Pictures</a>
        <a href="../controller/logout.php">Logout</a>
        
    </nav>

    <div class="picture-box">
        <?php
        // Display the latest uploaded picture on the dashboard
        $pdo = new PDO('mysql:host=localhost;dbname=studymate', 'root', '');
        $stmt = $pdo->query('SELECT name, data FROM pictures ');
        $row = $stmt->fetch();
        if ($row) {
            $name = $row['name'];
            $data = $row['data'];
            $base64 = base64_encode($data);
            echo '<img src="data:image/jpeg;base64,' . $base64 . '" alt="' . $name . '">';
        }
        ?>
    </div>

    <div class="content">
        <!-- Your content here -->
        <div id="profile">
        <!-- Profile information will be displayed here -->
    </div>

    <button id="addDescriptionBtn" style="font-size: 13px; background-color: blue; padding: 12px 24px; color: white; border: none; border-radius: 8px;">Add Description</button>

    <div id="descriptionForm" style="display: none;">
    <h2>Add Description</h2>
    <form id="descriptionInputForm">
        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4" cols="50" required></textarea>
        <br>
        <button type="submit">Save Description</button>
    </form>
</div>
    </div>
    <script>
        const addDescriptionBtn = document.getElementById("addDescriptionBtn");
        const descriptionForm = document.getElementById("descriptionForm");
        const descriptionInputForm = document.getElementById("descriptionInputForm");
        const profileSection = document.getElementById("profile");

        // Check if a description is already saved in local storage
        const savedDescription = localStorage.getItem("userDescription");
        if (savedDescription) {
            profileSection.innerHTML = `<h2>User Description:</h2><p>${savedDescription}</p>`;
        }

        addDescriptionBtn.addEventListener("click", () => {
            descriptionForm.style.display = "block";
        });

        descriptionInputForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const descriptionInput = document.getElementById("description").value;
            profileSection.innerHTML = `<h2>User Description:</h2><p>${descriptionInput}</p>`;
            
            // Save the description to local storage
            localStorage.setItem("userDescription", descriptionInput);
            
            descriptionForm.style.display = "none";
        });
    </script>
</body>
</html>

<!-- index.php -->

<!DOCTYPE html>
<html>
<head>
  <!-- Your head content here -->
  <style>
    /* Add some basic styling to hide the group information by default */
    .group-info {
      display: none;
      margin-top: 10px;
      padding: 10px;
      border: 1px solid #ccc;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Home Page</h2>
    <!-- Your other home page content here -->

    <!-- "Make a Group" button -->
    <button id="showGroupButton">See Created Groups</button>

    <!-- Group Information -->
    <div class="group-info">
      <?php
      // Include the database connection file
      require_once('../model/userModel.php');

      // Connect to the database (using the connection from db.php)
      // Make sure to properly configure the connection credentials in db.php
      $conn = getConnection();

      // Check for errors
      if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

      // Retrieve group information from the database
      $sql = "SELECT * FROM groups"; // You can add WHERE clause to filter data based on your requirements
      $result = mysqli_query($conn, $sql);

      // Display the group information
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<div>";
        echo "<h3>Group Name: " . htmlspecialchars($row['group_name']) . "</h3>";
        echo "<p>Description: " . htmlspecialchars($row['group_description']) . "</p>";
        echo "<p>Privacy: " . htmlspecialchars($row['group_privacy']) . "</p>";
        // Add more information or formatting as needed
        echo "</div>";
      }

      // Close the database connection
      mysqli_close($conn);
      ?>
    </div>
  </div>

  <!-- JavaScript to toggle the visibility of group information -->
  <script>
    const showGroupButton = document.getElementById('showGroupButton');
    const groupInfo = document.querySelector('.group-info');

    showGroupButton.addEventListener('click', () => {
      // Toggle the visibility of the group information
      groupInfo.style.display = groupInfo.style.display === 'block' ? 'none' : 'block';
    });
  </script>
</body>
</html>





<!DOCTYPE html>
<html>
<body>
    <h1>Express Your Mind</h1>
    <form action="save_post.php" method="post">
        <label for="thought">Your Thoughts:</label><br>
        <textarea id="thought" name="thought" rows="5" cols="50" required></textarea><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>



<!DOCTYPE html>
<html>
<body>

<?php
// Connect to the database (replace with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studymate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle post deletion if the delete button is clicked
if(isset($_POST['delete_post'])){
    $post_id = $_POST['delete_post'];
    $sql = "DELETE FROM posts WHERE id = $post_id";
    $conn->query($sql);
}

// Fetch all the saved posts from the database
$sql = "SELECT * FROM posts";
$result = $conn->query($sql);

// Display the posts
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row["thought"] . "</p>";
        // Add a delete button for each post
        echo '<form method="post">';
        echo '<button type="submit" name="delete_post" value="' . $row["id"] . '">Delete Posts</button>';
        echo '</form>';
        echo "<hr>";
    }
} else {
    echo "No posts found.";
}

// Close the connection
$conn->close();
?>

<p>Click the button below to upload a video.</p>
<a href="upload_video.php">
    <button style="font-size: 16px; background-color: green; padding: 10px 20px; color: white; border: none; border-radius: 5px;">Upload Video</button>
</a>

    

</body>
</html>


<!DOCTYPE html>
<html>
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "studymate";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the video details from the database
    $sql = "SELECT file_name, file_type FROM videos ORDER BY id DESC LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $videoName = $row['file_name'];
        $videoType = $row['file_type'];

        // Path to the uploaded video
        $videoPath = "uploads/" . $videoName;

        // Display the video using the HTML video element
        echo '<video width="640" height="360" controls>';
        echo '<source src="' . $videoPath . '" type="' . $videoType . '">';
        echo 'Your browser does not support the video tag.';
        echo '</video>';
    } else {
        echo 'No video uploaded yet.';
    }

    $conn->close();
    // Fetch the video details from the database
$sql = "SELECT file_name, file_type FROM videos ORDER BY upload_date DESC LIMIT 1";

    ?>
</body>
</html>







