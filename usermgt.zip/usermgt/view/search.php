<!DOCTYPE html>
<html>
<head>
    <title>User Search Results</title>
</head>
<body>
    <h1>User Search Results</h1>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
        $searchTerm = $_POST["search"];

        
        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "studymate";

        
        $conn = new mysqli($host, $username, $password, $dbname);

        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        
        $sql = "SELECT * FROM users WHERE username LIKE '%$searchTerm%' OR email LIKE '%$searchTerm%';";

        
        $result = $conn->query($sql);

        
        if ($result->num_rows > 0) {
            echo "<ul>";
            while ($row = $result->fetch_assoc()) {
                echo "<li>{$row['username']} - {$row['email']}</li>";
            }
            echo "</ul>";
        } else {
            echo "No results found.";
        }

      
        $conn->close();
        
    }
    ?>
    <button onclick="window.location.href='home.php'" class="back-button">Back to Home</button>
</body>
</html>
