<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studymate";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    // Establish a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Process the video data
    $title = $_POST["title"];
    $description = $_POST["description"];
    $file_name = $_FILES["video"]["name"];
    $tmp_name = $_FILES["video"]["tmp_name"];

    // Move the video to a permanent location
    $upload_path = "videos/"; // Make sure this directory exists and has proper permissions
    $target_file = $upload_path . basename($file_name);
    if (move_uploaded_file($tmp_name, $target_file)) {
        // Insert video information into the database
        $sql = "INSERT INTO videos (title, description, file_name) VALUES ('$title', '$description', '$file_name')";
        if ($conn->query($sql) === TRUE) {
            echo "Video uploaded successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

    // Close the database connection
    $conn->close();
}
?>
