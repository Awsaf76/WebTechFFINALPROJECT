<!DOCTYPE html>
<html>

<head>
  <title>Create Group</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }

    .container {
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    input[type="text"],
    select,
    textarea {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    textarea {
      resize: vertical;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: #fff;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
</head>

<body>
  <div class="container">
    <h2>Create Group</h2>
    <form action="group.php" method="POST">
      <div class="form-group">
        <label for="group_name">Group Name:</label>
        <input type="text" name="group_name" id="group_name" required>
      </div>

      <div class="form-group">
        <label for="group_description">Group Description:</label>
        <textarea name="group_description" id="group_description" rows="5" required></textarea>
      </div>

      <div class="form-group">
        <label for="group_privacy">Group Privacy:</label>
        <select name="group_privacy" id="group_privacy" required>
          <option value="">Select Privacy</option>
          <option value="public">Public</option>
          <option value="private">Private</option>
        </select>
      </div>

      <div class="form-group">
        <h1><input type="submit" name="submit" value="Create Group"></h1>
      </div>
    </form>
  </div>
</body>

</html>
<?php
session_start();

// Include the database connection file
require_once('../model/userModel.php');

if (isset($_POST['submit'])) {
  $group_name = $_POST['group_name'];
  $group_description = $_POST['group_description'];
  $group_privacy = $_POST['group_privacy'];

  $conn = getConnection();

  // Check for errors
  if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
  }

  // Prepare the SQL statement using a prepared statement
  $stmt = mysqli_prepare($conn, "INSERT INTO groups (group_name, group_description, group_privacy, user_id) VALUES (?, ?, ?, ?)");
  mysqli_stmt_bind_param($stmt, "sssi", $group_name, $group_description, $group_privacy, $user_id);

  // Execute the prepared statement
  if (mysqli_stmt_execute($stmt)) {
    // Group created successfully
    echo "Group created successfully.";
  } else {
    // Error creating group
    echo "Error creating group: " . mysqli_error($conn);
  }

  // Close the prepared statement and the database connection
  mysqli_stmt_close($stmt);
  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        /* Style for the back button */
        #backButton {
            position: fixed;
            bottom: 20px;
            right: 20px;
            font-size: 20px;
            padding: 10px 20px;
        }
    </style>
</head>
<body>

    <style>
        /* Style for the back button */
        #backButton {
            position: fixed;
            bottom: 20px;
            right: 20px;
            font-size: 20px;
            padding: 10px 20px;
        }
    </style>
</head>
<body>

    <!-- Link to your other pages or navigation menu here -->

    <!-- Create the back button -->
    <button id="backButton">Back</button>

    <script>
        // Get the back button element
        const backButton = document.getElementById("backButton");

        // Add a click event listener to the back button
        backButton.addEventListener("click", () => {
            // Use the history object to go back one step in the browser history
            window.history.back();
        });
    </script>
</body>
</html>

</body>
</html>
