<?php
// delete_video.php

if (isset($_POST['delete']) && isset($_POST['video_id'])) {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "studymate";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the video ID from the form submission
    $videoId = $_POST['video_id'];

    // Retrieve the video details from the database
    $sql = "SELECT * FROM videos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $videoId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $videoName = $row['file_name'];

        // Delete the video file from the server
        $uploadPath = "uploads/";
        $filePath = $uploadPath . $videoName;
        if (file_exists($filePath)) {
            unlink($filePath); // Delete the file from the server
        }

        // Delete the video details from the database
        $deleteSql = "DELETE FROM videos WHERE id = ?";
        $deleteStmt = $conn->prepare($deleteSql);
        $deleteStmt->bind_param("i", $videoId);

        if ($deleteStmt->execute()) {
            echo "Video deleted successfully.";
        } else {
            echo "Error deleting video: " . $deleteStmt->error;
        }

        $deleteStmt->close();
    } else {
        echo "Video not found.";
    }

    $stmt->close();
    $conn->close();
}
?>
