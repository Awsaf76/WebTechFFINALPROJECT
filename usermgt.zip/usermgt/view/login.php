

<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>StudyMate | Login</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>
    
<header>
        <h1>StudyMate</h1>

    <nav>

        <a href="login.php">Login</a>
        <a href="signup.php">| Signup</a>

    </nav>
</header>
<form method="POST" action="../controller/loginCheck.php" onsubmit="return validateLoginForm()">
        Username: <input type="text" name="username" id="username" /><br><br>
        Password: <input type="password" name="password" id="password" /> <br><br>
        <input type="submit" name="submit" value="Submit" />
    </form>
</fieldset>
</fieldset>

<script>
    function validateLoginForm() {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        if (username === "") {
            alert("Please enter your username.");
            return false;
        }

        if (password === "") {
            alert("Please enter your password.");
            return false;
        }

        return true; // If all validation checks pass, the form will be submitted
    }
</script>
<script>
    function validateLoginForm() {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        if (username === "") {
            alert("Please enter your username.");
            return false;
        }

        if (password === "") {
            alert("Please enter your password.");
            return false;
        }

        return true; // If all validation checks pass, the form will be submitted
    }

    // Check for "msg" query parameter in the URL and show the appropriate message
    window.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const message = urlParams.get('msg');
        if (message === 'invalid') {
            alert('Invalid username/password');
        }
    });
</script>


</body>
</html>