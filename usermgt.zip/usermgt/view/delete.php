<?php 
    require_once('../model/userModel.php');
    $id = $_GET['id'];
    $user = getUser($id);
?>

<html lang="en">
<head>
    <title>Delete User</title>
</head>
<body>
    
        
</body>
</html>