<?php
session_start();

// Include the database connection file
require_once('../model/userModel.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the form data
    $thought = $_POST["thought"];

    // Create a connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "studymate";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to insert data into the database
    $sql = "INSERT INTO posts (thought) VALUES ('$thought')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Close the connection
        $conn->close();

        // Redirect to the home page after successful submission
        header("Location: home.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        $conn->close();
    }
}
?>

