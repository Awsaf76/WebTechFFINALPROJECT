<!DOCTYPE html>
<html>
<head>
    <title>Upload Video</title>
</head>
<body>
    <h1>Upload Video</h1>
    <form action="upload_video_db.php" method="post" enctype="multipart/form-data">
        <input type="file" name="video" accept="video/*">
        <input type="submit" name="submit" value="Upload">
    </form>
</body>
</html>
